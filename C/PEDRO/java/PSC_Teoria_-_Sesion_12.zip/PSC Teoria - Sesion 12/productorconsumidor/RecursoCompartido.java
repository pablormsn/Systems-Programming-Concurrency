package productorconsumidor;

import java.util.concurrent.Semaphore;

//Condición Productor:
//  No puedo almacenar hasta que no se ha leido.  
//Condición Consumidor:
// No puedo extraer hasta que no se ha almacenado uno nuevo. 
public class RecursoCompartido {
    private int recurso;

    public RecursoCompartido() {
    }

    public int extraer() {

        System.out.println("Extraído " + recurso);
        return recurso;
    }

    public void almacenar(int r) {

        recurso = r;
        System.out.println("Almacenado " + r);
    }

}
