package lectoresescritores;

import java.util.concurrent.*;

public class GestorBD {

	public void entraLector(int id) {

		System.out.println("Entra lector " + id + " Hay " + nLectores);

	}

	public void saleLector(int id) {

		System.out.println("Sale lector " + id + " Hay " + nLectores);

	}

	public void entraEscritor(int id) {

		System.out.println("                    Entra escritor " + id);
	}

	public void saleEscritor(int id) {
		System.out.println("             Sale escritor " + id);

	}

}
// CS-Escritores: exclusion mutua
// CS-Lectores: puede haber varios pero nunca con un escritor