package prPractica4PSYCej5;

public class Principal {

	public static void main(String[] args) {
		int num = 7;
		
		NodoFib n = new NodoFib(num);
		
		n.start();
		try {
			n.join();
			System.out.print("El fibonacci de " + num + " es: " +n.getRes());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}
