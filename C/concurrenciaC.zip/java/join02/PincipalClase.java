
package join02;

public class PrincipalClase(){
    RecursoCompartido rc = new RecursoCompartido();
    

}