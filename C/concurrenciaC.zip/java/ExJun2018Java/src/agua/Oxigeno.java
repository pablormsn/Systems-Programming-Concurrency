package agua;

import java.util.Random;

public class Oxigeno extends Thread{
	
	private static Random r = new Random();
	private int id;
	private GestorAgua2 gestor;
	
	public Oxigeno(int id, GestorAgua2 gestor){
		this.id = id;
		this.gestor = gestor;
	}

	
	public void run(){

		while (true){
		
			try {
			
				gestor.oListo(id);
				Thread.sleep(r.nextInt(1000));//espera para volver a entrar
				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}