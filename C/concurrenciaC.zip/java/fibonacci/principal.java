package fibonacci;

public class principal {
    public static void main(String[] args){
        fibonacci nacho = new fibonacci(10);
        Thread ignacio = new ignacio(Nacho);
        

    try {
        nacho.join();
    } catch (Exception e) {
        //TODO: handle exception
    }
    }

}
