#include <stdio.h>
#include <stdlib.h>
#include "colaPrior.h"
#include <string.h>

int main(){

T_Array a;
Crear(&a);

}